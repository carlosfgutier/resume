//hide and show sections
$("#skillsLink").click(function() {
    if ($("#skillsGrid").hasClass('hidden')) {
        $("#skillsGrid").removeClass('hidden');
        console.log($("#searchUI").classList);
    } else {
        $("#skillsGrid").addClass('hidden');
    };
});